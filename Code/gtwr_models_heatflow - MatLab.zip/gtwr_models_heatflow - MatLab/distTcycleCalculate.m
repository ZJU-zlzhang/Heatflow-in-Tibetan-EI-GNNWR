function dtcyc = distTcycleCalculate(timecycle, current_timecycle)
% current_timecycle = -1 ��ʾ����

global ct_distance_type

if current_timecycle == -1
    dtcyc = bsxfun(@minus,timecycle,timecycle');
    if ct_distance_type == 1
        timecylefloor = floor(timecycle);
        dtcycfloor = bsxfun(@minus,timecylefloor,timecylefloor');
        %���죨1,2,3�£�-���죨10,11,12�£�
        dtcyc(dtcycfloor == -3) = dtcyc(dtcycfloor == -3) + 4;
        %���죨10,11,12�£�-���죨1,2,3�£�
        dtcyc(dtcycfloor == 3) = dtcyc(dtcycfloor == 3) - 4;
    end;
else
    dtcyc = timecycle - current_timecycle;
    if ct_distance_type == 1
        timecylefloor = floor(timecycle);
        dtcycfloor = timecylefloor - floor(current_timecycle);
        %���죨1,2,3�£�-���죨10,11,12�£�
        dtcyc(dtcycfloor == -3) = dtcyc(dtcycfloor == -3) + 4;
        %���죨10,11,12�£�-���죨1,2,3�£�
        dtcyc(dtcycfloor == 3) = dtcyc(dtcycfloor == 3) - 4;
    end;
end;





