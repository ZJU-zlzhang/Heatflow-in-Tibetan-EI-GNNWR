function result = gctwr(y,x,east,north,timecycle,timenoncycle,info)
% PURPOSE: compute geographically and cycle temporally weighted regression

global curResbandwidthOrQInfo;
global curResomegaInfo;
global bestFunVars;
global bdwtIntervalSize;
global qIntervalSize;
global kerneltype;
global model;
global logfid;
global logifdres;
global minbandwidth;
global ymax;
global ymin;
global y_noramlize;
global useQuick;
global ids;
global ids_model;
global travel_dis;

if nargin == 7 % user options
    if ~isstruct(info)
        error('gctwr: must supply the option argument as a structure variable');
    else
        fields = fieldnames(info);
        nf = length(fields);
        % set defaults
        [n k] = size(x);
        bwidth = 0; dtype = 0; q = 0; qmin = k+2; qmax = 5*k;
        lamuda = 0; omega = 0;
        bmin = 0.1; bmax = 20.0;
        lamudamin = 0; lamudamax = 10.0;
        omegamin = 0; omegamax = 20.0;
        expindex = 2; expindexmin = 1; expindexmax = 4;
        method = 0;
        CVmethod = 'RSS';
        output = 0;
        dstring = '';
        
        train_index = -1;
        val_index = -1;
        test_index = -1;
        model_index = -1;
        
        for i=1:nf
            if strcmp(fields{i},'bwidth')
                bwidth = info.bwidth;
            elseif strcmp(fields{i},'dtype')
                dstring = info.dtype;
                if strcmp(dstring,'gaussian')
                    dtype = 0;
                elseif strcmp(dstring,'exponential')
                    dtype = 1;
                elseif strcmp(dstring,'bi-square')
                    dtype = 2;
                elseif strcmp(dstring,'tri-cube')
                    dtype = 3;
                end;
            elseif strcmp(fields{i},'q')
                q = info.q;
            elseif strcmp(fields{i},'qmax');
                qmax = info.qmax;
            elseif strcmp(fields{i},'qmin');
                qmin = info.qmin;
            elseif strcmp(fields{i},'bmin');
                bmin = info.bmin;
            elseif strcmp(fields{i},'bmax');
                bmax = info.bmax;
            elseif strcmp(fields{i},'lamudamin');
                lamudamin = info.lamudamin;
            elseif strcmp(fields{i},'lamudamax');
                lamudamax = info.lamudamax;
             elseif strcmp(fields{i},'omegamin');
                omegamin = info.omegamin;
            elseif strcmp(fields{i},'omegamax');
                omegamax = info.omegamax;
            elseif strcmp(fields{i},'expindexmin');
                expindexmin = info.expindexmin;
            elseif strcmp(fields{i},'expindexmax');
                expindexmax = info.expindexmax;
            elseif strcmp(fields{i},'expindex');
                expindex = info.expindex;
            elseif strcmp(fields{i},'method');
                CVmethod = info.method;
                if strcmp(CVmethod,'RSS')
                    method = 0;
                elseif strcmp(CVmethod,'AICc')
                    method = 1;
                end;
            elseif strcmp(fields{i},'lamuda');
                lamuda = info.lamuda;
            elseif strcmp(fields{i},'omega');
                omega = info.omega;
            elseif strcmp(fields{i},'output');
                output = info.output;
            elseif strcmp(fields{i},'train');
                train_index = info.train;
            elseif strcmp(fields{i},'validation');
                val_index = info.validation;
            elseif strcmp(fields{i},'test');
                test_index = info.test;
            elseif strcmp(fields{i},'modelindex');
                model_index = info.modelindex;
            end;
        end; % end of for i
    end; % end of if else
    
elseif nargin == 4
    bwidth = 0; dtype = 0; dstring = 'gaussian';
    bmin = 0.1; bmax = 20.0;
else
    error('Wrong # of arguments to gwr');
end;

if val_index ~= -1
    val_y = y(val_index, :);
    val_x = x(val_index, :);
    val_east = east(val_index, :);
    val_north = north(val_index, :);
    val_timecycle = timecycle(val_index, :);
    val_timenoncycle = timenoncycle(val_index, :);
    val_ids = ids(val_index, :);
end;

if test_index ~= -1
    test_y = y(test_index, :);
    test_x = x(test_index, :);
    test_east = east(test_index, :);
    test_north = north(test_index, :);
    test_timecycle = timecycle(test_index, :);
    test_timenoncycle = timenoncycle(test_index, :);
    test_ids = ids(test_index, :);
end;

% train_index�Ǹ��������Ǳ�trainһ�µ�����������һ��������ģ
if train_index ~= -1
    train_y = y(train_index, :);
    train_x = x(train_index, :);
    train_east = east(train_index, :);
    train_north = north(train_index, :);
    train_timecycle = timecycle(train_index, :);
    train_timenoncycle = timenoncycle(train_index, :);
    train_ids = ids(train_index, :);
end;

% model_index��������ģ�ģ�ͨ������train+validation
if model_index ~= -1
    y = y(model_index, :);
    x = x(model_index, :);
    east = east(model_index, :);
    north = north(model_index, :);
    timecycle = timecycle(model_index, :);
    timenoncycle = timenoncycle(model_index, :);
    ids_model = ids(model_index, :);
end;


% error checking on inputs
[nobs nvar] = size(x);
[nobs2 junk] = size(y);
[nobs3 junk] = size(north);
[nobs4 junk] = size(east);
[nobs5 junk] = size(timecycle);
[nobs6 junk] = size(timenoncycle);

result.y = y;
result.x = x;
result.north = north;
result.east = east;
result.timecycle = timecycle;
result.timenoncycle = timenoncycle;

if nobs ~= nobs2
    error('gctwr: y and x must contain same # obs');
elseif nobs3 ~= nobs
    error('gctwr: north coordinates must equal # obs');
elseif nobs3 ~= nobs4
    error('gctwr: east coordinates must equal # in north');
elseif nobs4 ~= nobs5
    error('gctwr: timecycle coordinates must equal # in east');
elseif nobs5 ~= nobs6
    error('gctwr: timecycle coordinates must equal # in timenoncycle');
end;


disp([datestr(now,'HH:MM:SS') ' --------------begin model:' char(model) '_' char(dstring) '_' char(kerneltype) '_CV_' char(CVmethod)]);
fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') ' --------------begin model:' char(model) '_' char(dstring) '_' char(kerneltype) '_CV_' char(CVmethod)]);

funVars.y = y;
funVars.x = x;
funVars.east = east;
funVars.north = north;
funVars.timecycle = timecycle;
funVars.timenoncycle = timenoncycle;
funVars.bmin = bmin;
funVars.bmax = bmax;
funVars.qmin = qmin;
funVars.qmax = qmax;
funVars.lamudamin = lamudamin;
funVars.lamudamax = lamudamax;
funVars.omegamin = omegamin;
funVars.omegamax = omegamax;
funVars.method = method;
funVars.expindex = expindex;
funVars.dtype = dtype;

if output
    if strcmp(kerneltype,'fixed')
        lamuda = info.lamuda;
        omega = info.omega;
        if bwidth == 0
            if minbandwidth == 1
                minBand = calMinBandwidth(lamuda, omega);
                funVars.bmin = minBand;
                bmin = minBand;
            end;
            %����ʱ�վ�������ֵ������bmax�����ֵ����Ϊ����
            maxDst = calBandwidth(lamuda, omega, -1);
            funVars.lamuda = lamuda;
            funVars.omega = omega;
            funVars.bmax = maxDst;
            rmsearch('gctwrScorefBandwidth','fminbnd',bmin,bmin,maxDst,funVars,'initialsample',bdwtIntervalSize,'plot','off');
            bdwt = bestFunVars.bestBQ;
        end;

        disp([datestr(now,'HH:MM:SS') ' best lamuda:' num2str(lamuda) ', best omega:' num2str(omega) ', best bdwt:' num2str(bdwt)]);
        
    else % q-nearest neigbhor cross-validation
        lamuda = info.lamuda;
        omega = info.omega;
        
        if q == 0        
            funVars.lamuda = lamuda;
            funVars.omega = omega;
            rmsearch('gctwrScorefBandwidth','fminbnd',qmin,qmax,qmax,funVars,'initialsample',qIntervalSize,'plot','off');
            q = round(bestFunVars.bestBQ);
        end;
        
        disp([datestr(now,'HH:MM:SS') ' best lamuda:' num2str(lamuda) ', best omega:' num2str(omega) ', best q:' num2str(q)]);
        
    end;
else
    if strcmp(kerneltype,'fixed') 
        if bwidth == 0
            [lamuda, omega, bdwt] = gctwrScorefModel(lamudamin,lamudamax,omegamin,omegamax,bmin,bmax,qmin,qmax,y,x,east,north,timecycle,timenoncycle,dtype,method);
        else
            bdwt = bwidth; % user supplied bandwidth
        end; 
        disp([datestr(now,'HH:MM:SS') ' best lamuda:' num2str(lamuda) ', best omega:' num2str(omega) ', best bdwt:' num2str(bdwt)]);
    else
        if q == 0
            [lamuda, omega, q] = gctwrScorefModel(lamudamin,lamudamax,omegamin,omegamax,bmin,bmax,qmin,qmax,y,x,east,north,timecycle,timenoncycle,dtype,method);
            q = round(q);
        end;
        disp([datestr(now,'HH:MM:SS') ' best lamuda:' num2str(lamuda) ', best omega:' num2str(omega) ', best q:' num2str(q)]);
    end;    
end;

% do GWR using bdwt as bandwidth
[n k] = size(x);
bsave = zeros(n,k);
ssave = zeros(n,k);
sigv  = zeros(n,1);
yhat  = zeros(n,1);
resid = zeros(n,1);
hatM = zeros(n,n);
hatM_temp = zeros(k,n,n);
for iter=1:n;
    dx = east - east(iter,1);
    dy = north - north(iter,1);
    dtcyc = distTcycleCalculate(timecycle, timecycle(iter,1));
    dtnoncyc = timenoncycle - timenoncycle(iter,1);
    dtnoncyc = travel_dis(ids_model(iter), ids_model).';
    dst2 = distSTCalculate(dx, dy, dtcyc, dtnoncyc, omega, lamuda);
    dst = sqrt(dst2);   
    
    if strcmp(kerneltype,'fixed') 
        nzip = find(dst <= bdwt);
        wt = zeros(n,1);
        if dtype == 0,     % Gausian weights
            wt = exp(-0.5*dst2/(bdwt*bdwt));
        elseif dtype == 1, % exponential weights
            wt = exp(-1.0*dst/(bdwt));
        elseif dtype == 2, % bi-square weights
            wt(nzip,1) = (1-(dst(nzip,1)/bdwt).^2).^2;
        elseif dtype == 3, % tri-cube weights
            wt(nzip,1) = (1-(dst(nzip,1)/bdwt).^3).^3;
        end; % end of if,else
    else
        % sort distance to find q nearest neighbors
        dsort = sort(dst);
        dstmax = dsort(q,1);
        wt = zeros(n,1);
        nzip = find(dst <= dstmax);
        if dtype == 0,     % Gausian weights
            wt(nzip,1) = exp(-0.5*dst2(nzip,1)/(dstmax*dstmax));
        elseif dtype == 1, % exponential weights
            wt(nzip,1) = exp(-1.0*dst(nzip,1)/(dstmax));
        elseif dtype == 2, % bi-square weights
            wt(nzip,1) = (1-(dst(nzip,1)/dstmax).^2).^2;
        elseif dtype == 3, % tri-cube weights
            wt(nzip,1) = (1-(dst(nzip,1)/dstmax).^3).^3;
        end; % end of if,else
    end; % end of if,else
    wt = sqrt(wt);
    
    
    % computational trick to speed things up
    % use non-zero wt to pull out y,x observations
    nzip = find(wt > 0.0);
    ys = y(nzip,1).*wt(nzip,1);
    xs = matmul(x(nzip,:),wt(nzip,1));
    xpxi = invpd(xs'*xs);
    b = xpxi*xs'*ys;
    % compute predicted values
    yhatv = xs*b;
    yhat(iter,1) = x(iter,:)*b;
    resid(iter,1) = y(iter,1) - yhat(iter,1);
    
    xn = matmul(x,wt);
    if sum(sum(isnan(xn'*xn))) > 0 || sum(sum(isinf(xn'*xn))) > 0
        hatM(iter,:) = ones(1, n) * NaN;
        hatM_temp(:,:,iter) = ones(k,n) * NaN;
    else
        hatM(iter,:) = x(iter,:) * (invpd(xn'*xn) * (matmul(xn,wt))');
        hatM_temp(:,:,iter) = (invpd(xn'*xn) * (matmul(xn,wt))');
    end;
    
       
    % compute residuals
    e = ys - yhatv;
    % find # of non-zero observations
    nadj = length(nzip);
    sige = (e'*e)/nadj;
    
    % compute t-statistics
    sdb = sqrt(sige*diag(xpxi));
    % store coefficient estimates and std errors in matrices
    % one set of beta,std for each observation
    bsave(iter,:) = b';
    ssave(iter,:) = sdb';
    sigv(iter,1) = sige;
end;


% Lee 2000����F1��F2����
hatMOLS = x*invpd(x'*x)*x';
OLSbeta = invpd(x'*x)*x'*y;
R0 = (eye(n)-hatMOLS)'*(eye(n)-hatMOLS);
R1 = (eye(n)-hatM)'*(eye(n)-hatM);
diffMat = R0 - R1;

mu1 = trace(diffMat);
deta1 = trace(R1);
mu2 = trace(diffMat*diffMat);
deta2 = trace(R1*R1);

result.F1d1 = (deta1 * deta1) / deta2;
result.F1d2 = nobs-nvar;
result.F1 = (y'*R1*y / deta1) / (y'*R0*y / (nobs-nvar));

result.F2d1 = (mu1 * mu1) / mu2;
result.F2d2 = nobs-nvar;
result.F2 = ((y'*R0*y-y'*R1*y) / mu1) / (y'*R0*y / (nobs-nvar));

traceS = trace(hatM);

J_n = 1/n * ones(n,n);

result.F3s = zeros(k,1);
result.F3d1s = zeros(k,1);
result.F3d2s = zeros(k,1);

for iter=1:k;
    e_k = zeros(1, k);
    e_k(iter) = 1;
    e_k_matrix = repmat(e_k, [n, 1]);
    
    e_k_matrix_2 = permute(e_k_matrix,[3,2,1]);
    if useQuick
        hatB = mtimesx(e_k_matrix_2,hatM_temp);
        hatB = permute(hatB,[2,3,1]);
    else
        for ii=1:n
            hatB_temp(:,:,ii)= e_k_matrix_2(:,:,ii)*hatM_temp(:,:,ii);
        end
        hatB = permute(hatB_temp,[2,3,1]);
    end;

    L_n = 1/n * hatB' * (eye(n) - J_n) * hatB;
    vk2 = y' * L_n * y;
    trace_L_n = trace(L_n);
    result.F3s(iter) = vk2 / trace_L_n / (y'*R1*y / deta1);
    result.F3d1s(iter) = trace_L_n * trace_L_n / trace(L_n * L_n);
    result.F3d2s(iter) = result.F1d1;
end;


if y_noramlize == 1
    result.RSS_Real = resid'*resid * (ymax-ymin) * (ymax-ymin);
    result.yhat_Real = yhat * (ymax - ymin) + ymin;
else
    result.RSS_Real = resid'*resid;
    result.yhat_Real = yhat;
end;

result.AICc = 2 * n * log(sqrt(result.RSS_Real / n)) + n * log(6.2831853071795862) + n * (n + traceS) / (n - 2.0 - traceS);

traceOLS = trace(hatMOLS);
result.OLSRss = y'*R0*y;
result.OLSyhat = hatMOLS * y;
ols_val_pred_yhat = val_x * OLSbeta;
ols_test_pred_yhat = test_x * OLSbeta;
result.OLSyhat = [result.OLSyhat; ols_val_pred_yhat; ols_test_pred_yhat];

if y_noramlize == 1
    result.OLSRss_Real = result.OLSRss * (ymax-ymin) * (ymax-ymin);
    result.OLSyhat_Real = result.OLSyhat * (ymax-ymin) + ymin;
else
    result.OLSRss_Real = result.OLSRss;
    result.OLSyhat_Real = result.OLSyhat;
end;

result.OLSAIC = 2 * n * log(sqrt(result.OLSRss_Real / n)) + n * log(6.2831853071795862) + n * (n + traceOLS) / (n - 2.0 - traceOLS);
result.OLSMS = result.OLSRss_Real / (nobs-nvar);

% fill-in results structure
% result.meth = [char(model) '_' char(dstring) '_' char(kerneltype) '_CV_' char(CVmethod)];

if strcmp(CVmethod,'RSS')
    CVName = 'CV';
else
    CVName = CVmethod;
end;

result.meth = [char(model) '_' char(CVName) '_' char(kerneltype) '_' char(dstring)];


% ģ����д
model_u = upper(char(model));
CVName_u = upper(char(CVName));
kerneltype_u = upper(char(kerneltype));
dstring_u = upper(char(dstring));
result.meth_abbr = [model_u '_' CVName_u(1) kerneltype_u(1) dstring_u(1)];

result.nobs = nobs;
result.nvar = nvar;
result.lamuda = lamuda;
result.omega = omega;

bqname = 'bwidth';
if strcmp(kerneltype,'fixed')
    result.bwidth = bdwt;
else
    result.bwidth = q;
    bqname = 'q';
end;
result.beta = bsave;
result.tstat = bsave./ssave;
result.sige = sigv;
result.dtype = char(dstring);
result.y = y;
result.yhat = yhat;
% compute residuals and conventional r-squared
result.resid = resid;
sigu = result.resid'*result.resid;
result.sigu = sigu;
result.degree = deta1;
result.MS = result.RSS_Real / deta1;
ym = y - mean(y);
rsqr1 = sigu;
rsqr2 = ym'*ym;
result.rsqr = 1.0 - rsqr1/rsqr2; % r-squared
rsqr1 = rsqr1/(deta1);
rsqr2 = rsqr2/(nobs-1.0);
result.rbar = 1 - (rsqr1/rsqr2); % rbar-squared

% OLS���
rsqr1 = result.OLSRss;
rsqr2 = ym'*ym;
result.OLSrsqr = 1.0 - rsqr1/rsqr2; % r-squared
rsqr1 = rsqr1/(nobs - nvar);
rsqr2 = rsqr2/(nobs-1.0);
result.OLSrbar = 1 - (rsqr1/rsqr2); % rbar-squared


result.curResbandwidthOrQInfo = curResbandwidthOrQInfo;
result.curResomegaInfo = curResomegaInfo;

disp([datestr(now,'HH:MM:SS') ' best lamuda:' num2str(lamuda) ', best omega:' num2str(omega) ', best ' bqname ':' num2str(result.bwidth) ', F1:' num2str(result.F1) ', F2:' num2str(result.F2) ', RSS:' num2str(result.RSS_Real) ', AICc:' num2str(result.AICc) ', R2:' num2str(result.rsqr) ', adjusted-R2:' num2str(result.rbar)]); 
fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') ' best lamuda:' num2str(lamuda) ', best omega:' num2str(omega) ', best ' bqname ':' num2str(result.bwidth) ', F1:' num2str(result.F1) ', F2:' num2str(result.F2) ', RSS:' num2str(result.RSS_Real) ', AICc:' num2str(result.AICc) ', R2:' num2str(result.rsqr) ', adjusted-R2:' num2str(result.rbar)]); 

fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') '--------------end model:' result.meth]);
disp([datestr(now,'HH:MM:SS') '--------------end model:' result.meth]);

% fprintf(logifdres,'%s\n', [datestr(now,'HH:MM:SS') ' ' result.meth ': best lamuda:' num2str(lamuda) ', best omega:' num2str(omega) ', best ' bqname ':' num2str(result.bwidth) ', F1:' num2str(result.F1) ', F2:' num2str(result.F2) ', RSS:' num2str(result.RSS_Real) ', AICc:' num2str(result.AICc) ', R2:' num2str(result.rsqr) ', adjusted-R2:' num2str(result.rbar)]); 
fprintf(logifdres,'%s\n', [datestr(now,'HH:MM:SS') ' ' result.meth '(' result.meth_abbr '): best lamuda:' num2str(lamuda) ', best omega:' num2str(omega) ', best ' bqname ':' num2str(result.bwidth) ', RSS:' num2str(result.RSS_Real) ', MS:' num2str(result.MS) ', R2:' num2str(result.rsqr) ', adjusted-R2:' num2str(result.rbar) ', AICc:' num2str(result.AICc) ', F1:' num2str(result.F1) ', F2:' num2str(result.F2)]); 



if train_index ~= -1
    result.train_prediction = gctwr_prediction(train_y, train_x, train_east, train_north, train_timecycle, train_timenoncycle, train_ids);
    result.ols_train_prediction = ols_prediction(train_y, train_x, OLSbeta);
end;

if val_index ~= -1
    result.val_prediction = gctwr_prediction(val_y, val_x, val_east, val_north, val_timecycle, val_timenoncycle, val_ids);
    result.ols_val_prediction = ols_prediction(val_y, val_x, OLSbeta);
end;

if test_index ~= -1
    result.test_prediction = gctwr_prediction(test_y, test_x, test_east, test_north, test_timecycle, test_timenoncycle, test_ids);
    result.ols_test_prediction = ols_prediction(test_y, test_x, OLSbeta);
end;


function predict_result = gctwr_prediction(pred_y,pred_x,pred_east,pred_north,pred_timecycle,pred_timenoncycle, pred_ids)

predict_result.pred_y = pred_y;
predict_result.pred_x = pred_x;
predict_result.pred_east = pred_east;
predict_result.pred_north = pred_north;
predict_result.pred_timecycle = pred_timecycle;
predict_result.pred_timenoncycle = pred_timenoncycle;

[pred_n, nvar] = size(pred_x);

for iter=1:pred_n;
    dx = east - pred_east(iter,1);
    dy = north - pred_north(iter,1);
    dtcyc = distTcycleCalculate(timecycle, pred_timecycle(iter,1));
    dtnoncyc = timenoncycle - pred_timenoncycle(iter,1);
    dtnoncyc = travel_dis(pred_ids(iter), ids_model).';
    dst2 = distSTCalculate(dx, dy, dtcyc, dtnoncyc, omega, lamuda);
    dst = sqrt(dst2);   
    
    if strcmp(kerneltype,'fixed') 
        nzip = find(dst <= bdwt);
        wt = zeros(n,1);
        if dtype == 0,     % Gausian weights
            wt = exp(-0.5*dst2/(bdwt*bdwt));
        elseif dtype == 1, % exponential weights
            wt = exp(-1.0*dst/(bdwt));
        elseif dtype == 2, % bi-square weights
            wt(nzip,1) = (1-(dst(nzip,1)/bdwt).^2).^2;
        elseif dtype == 3, % tri-cube weights
            wt(nzip,1) = (1-(dst(nzip,1)/bdwt).^3).^3;
        end; % end of if,else
    else
        % sort distance to find q nearest neighbors
        dsort = sort(dst);
        dstmax = dsort(q,1);
        wt = zeros(n,1);
        nzip = find(dst <= dstmax);
        if dtype == 0,     % Gausian weights
            wt(nzip,1) = exp(-0.5*dst2(nzip,1)/(dstmax*dstmax));
        elseif dtype == 1, % exponential weights
            wt(nzip,1) = exp(-1.0*dst(nzip,1)/(dstmax));
        elseif dtype == 2, % bi-square weights
            wt(nzip,1) = (1-(dst(nzip,1)/dstmax).^2).^2;
        elseif dtype == 3, % tri-cube weights
            wt(nzip,1) = (1-(dst(nzip,1)/dstmax).^3).^3;
        end; % end of if,else
    end; % end of if,else
    wt = sqrt(wt);
    
    
    % computational trick to speed things up
    % use non-zero wt to pull out y,x observations
    nzip = find(wt > 0.0);
    ys = y(nzip,1).*wt(nzip,1);
    xs = matmul(x(nzip,:),wt(nzip,1));
    xpxi = invpd(xs'*xs);
    b = xpxi*xs'*ys;
    % compute predicted values
    yhatv = xs*b;
    pred_yhat(iter,1) = pred_x(iter,:)*b;
    pred_resid(iter,1) = pred_y(iter,1) - pred_yhat(iter,1);
  
       
    % compute residuals
    e = ys - yhatv;
    % find # of non-zero observations
    nadj = length(nzip);
    sige = (e'*e)/nadj;
    
    % compute t-statistics
    sdb = sqrt(sige*diag(xpxi));
    % store coefficient estimates and std errors in matrices
    % one set of beta,std for each observation
    pred_bsave(iter,:) = b';
    pred_ssave(iter,:) = sdb';
    pred_sigv(iter,1) = sige;
end

predict_result.beta = pred_bsave;
predict_result.tstat = pred_bsave./pred_ssave;
predict_result.sige = pred_sigv;
predict_result.yhat = pred_yhat;
% compute residuals and conventional r-squared
predict_result.resid = pred_resid;
predict_result.sigu = pred_resid'*pred_resid;
if y_noramlize == 1
    predict_result.RSS_Real = pred_resid'*pred_resid * (ymax-ymin) * (ymax-ymin);
    predict_result.yhat_Real = pred_yhat * (ymax - ymin) + ymin;
    predict_result.y_Real = pred_y * (ymax - ymin) + ymin;
else
    predict_result.RSS_Real = pred_resid'*pred_resid;
    predict_result.yhat_Real = pred_yhat;
    predict_result.y_Real = pred_y;
end;
predict_result.degree = pred_n-nvar;
predict_result.MS = predict_result.RSS_Real / pred_n;
pred_ym = pred_y - mean(pred_y);
rsqr1 = pred_resid'*pred_resid;
rsqr2 = pred_ym'*pred_ym;
predict_result.rsqr = 1.0 - rsqr1/rsqr2; % r-squared
rsqr1 = rsqr1/(pred_n-nvar);
rsqr2 = rsqr2/(pred_n-1.0);
predict_result.rbar = 1 - (rsqr1/rsqr2); % rbar-squared

pearson_r_matrix = corrcoef(pred_y, pred_yhat);
predict_result.pearson_r = pearson_r_matrix(1,2);
predict_result.pearson_r2 = predict_result.pearson_r * predict_result.pearson_r;

predict_result.RMSE = sqrt(predict_result.RSS_Real / pred_n);
if y_noramlize == 1
    predict_result.MAE = sum(abs(pred_resid)) / pred_n * (ymax-ymin);   
    predict_result.MAPE = sum(abs(pred_resid) * (ymax-ymin) ./ max(predict_result.y_Real, 0.01)) / pred_n;
    
    predict_result.AE = abs(pred_resid) * (ymax-ymin);  
    predict_result.APE = abs(pred_resid) * (ymax-ymin) ./ max(predict_result.y_Real, 0.01);
else
    predict_result.MAE = sum(abs(pred_resid)) / pred_n;
    predict_result.MAPE = sum(abs(pred_resid) ./ max(pred_y, 0.01)) / pred_n;
    
    predict_result.AE = abs(pred_resid);
    predict_result.APE = abs(pred_resid) ./ max(pred_y, 0.01);
end;
predict_result.AICc = 2 * n * log(sqrt(predict_result.RSS_Real / n)) + n * log(6.2831853071795862) + n * (n + traceS) / (n - 2.0 - traceS);

end

function predict_result = ols_prediction(pred_y,pred_x, OLSbeta)

predict_result.pred_y = pred_y;
predict_result.pred_x = pred_x;
predict_result.beta = OLSbeta;
    
ols_pred_yhat = pred_x * OLSbeta;
ols_pred_resid = pred_y - ols_pred_yhat;
predict_result.resid = ols_pred_resid;
predict_result.sigu = predict_result.resid'*predict_result.resid;
if y_noramlize == 1
    predict_result.RSS_Real = predict_result.resid'*predict_result.resid * (ymax-ymin) * (ymax-ymin);
    predict_result.yhat_Real = ols_pred_yhat * (ymax - ymin) + ymin;
    predict_result.y_Real = pred_y * (ymax - ymin) + ymin;
else
    predict_result.RSS_Real = predict_result.resid'*predict_result.resid;
    predict_result.yhat_Real = ols_pred_yhat;
    predict_result.y_Real = pred_y;
end;

predict_result.AICc = 2 * n * log(sqrt(predict_result.RSS_Real / n)) + n * log(6.2831853071795862) + n * (n + traceS) / (n - 2.0 - traceS);

[pred_n, nvar] = size(pred_x);
predict_result.degree = pred_n-nvar;
predict_result.MS = predict_result.RSS_Real / pred_n;
pred_ym = pred_y - mean(pred_y);
rsqr1 = predict_result.sigu;
rsqr2 = pred_ym'*pred_ym;
predict_result.rsqr = 1.0 - rsqr1/rsqr2; % r-squared
rsqr1 = rsqr1/(pred_n-nvar);
rsqr2 = rsqr2/(pred_n-1.0);
predict_result.rbar = 1 - (rsqr1/rsqr2); % rbar-squared

pearson_r_matrix = corrcoef(pred_y, ols_pred_yhat);
predict_result.pearson_r = pearson_r_matrix(1,2);
predict_result.pearson_r2 = predict_result.pearson_r * predict_result.pearson_r;

predict_result.RMSE = sqrt(predict_result.RSS_Real / pred_n);
if y_noramlize == 1
    predict_result.MAE = sum(abs(ols_pred_resid)) / pred_n * (ymax-ymin);   
    predict_result.MAPE = sum(abs(ols_pred_resid) * (ymax-ymin) ./ max(predict_result.y_Real, 0.01)) / pred_n;
else
    predict_result.MAE = sum(abs(ols_pred_resid)) / pred_n;
    predict_result.MAPE = sum(abs(ols_pred_resid) ./ max(predict_result.y_Real, 0.01)) / pred_n;
end;

predict_result.AICc = 2 * n * log(sqrt(predict_result.RSS_Real / n)) + n * log(6.2831853071795862) + n * (n + traceS) / (n - 2.0 - traceS);

end

end



