function dtTran = dtTrantoSpace(dt,dtType)

global maxDs;
global minDs;
global meanDs;
global stdDs;
global maxDtcycle;
global minDtcycle;
global meanDtcycle;
global stdDtcycle;
global maxDtnoncycle;
global minDtnoncycle;
global meanDtnoncycle;
global stdDtnoncycle;
global maxDt;
global minDt;
global meanDt;
global stdDt;
global distTranMethod;
global distNormalize;

%��ʱ��
if strcmp(dtType,'total')
    maxDist = maxDt;
    minDist = minDt;
    meanDist = meanDt;
    stdDist = stdDt;

%������ʱ��
elseif strcmp(dtType,'cycle')
    maxDist = maxDtcycle;
    minDist = minDtcycle;
    meanDist = meanDtcycle;
    stdDist = stdDtcycle;

%��������ʱ��
elseif strcmp(dtType,'noncycle')
    maxDist = maxDtnoncycle;
    minDist = minDtnoncycle;
    meanDist = meanDtnoncycle;
    stdDist = stdDtnoncycle;
end

dt = abs(dt);

if distTranMethod == 1
    dtTran = ((dt - meanDist) / stdDist) * stdDs + meanDs;
else
    if distNormalize == 1
        dtTran = (dt - minDist) / (maxDist - minDist);
    else
        dtTran = (dt - minDist) / (maxDist - minDist) * (maxDs - minDs) + minDs;
    end;
end;
