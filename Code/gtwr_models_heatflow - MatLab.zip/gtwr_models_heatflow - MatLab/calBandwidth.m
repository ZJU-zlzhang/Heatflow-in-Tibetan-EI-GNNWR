function bandwidth = calBandwidth(lamuda, omega, divpara)
global maxDs;
global maxDtcycle;
global maxDtnoncycle;
global maxDt;
global maxDisDivPara;
global model;
global distNormalize;
global minbandwidth;

if distNormalize == 1
    maxDs_used = 1;
else
    maxDs_used = maxDs;
end;

if strcmp(model,'gwr')
    dst = maxDs_used;
elseif strcmp(model, 'twr') %�������twrʱ��dtnoncycӦ��������ܵ�ʱ���
    dtnoncyctoSpace = dtTrantoSpace(maxDt,'total');
    dst = dtnoncyctoSpace;
elseif strcmp(model,'ctwr')
    dtcyctoSpace = dtTrantoSpace(maxDtcycle,'cycle');
    dtnoncyctoSpace = dtTrantoSpace(maxDtnoncycle,'noncycle');
    dst = sqrt(dtnoncyctoSpace * dtnoncyctoSpace + dtcyctoSpace * dtcyctoSpace * omega);
elseif strcmp(model,'gtwr')%�������gtwrʱ��dtnoncycӦ��������ܵ�ʱ���
    dtnoncyctoSpace = dtTrantoSpace(maxDt,'total');
    dst = sqrt(maxDs_used * maxDs_used + lamuda * dtnoncyctoSpace * dtnoncyctoSpace);
elseif strcmp(model,'gctwr')
    dtcyctoSpace = dtTrantoSpace(maxDtcycle,'cycle');
    dtnoncyctoSpace = dtTrantoSpace(maxDtnoncycle,'noncycle');
    dt2 = dtnoncyctoSpace * dtnoncyctoSpace + dtcyctoSpace * dtcyctoSpace * omega;
    dst = sqrt(maxDs_used * maxDs_used + lamuda * dt2);
end;

if divpara == -1
    bandwidth = dst / maxDisDivPara;
        % ���ܻ�������ֵС����Сֵ�����
    if minbandwidth == 1
        minband = calMinBandwidth(lamuda, omega);
        if bandwidth < minband
            bandwidth = bandwidth + minband;
        end;
    end;
else
    bandwidth = dst / divpara;
end;

        
