function dst2 = distSTCalculate(dx, dy, dtcyc, dtnoncyc, omega, lamuda)

global model;
global maxDs;
global minDs;
global distNormalize;

if distNormalize == 1
    Ds_used = (sqrt(dx.*dx + dy.*dy) - minDs) / (maxDs - minDs);
    Ds2_used = Ds_used.*Ds_used;
else
    Ds2_used = dx.*dx + dy.*dy;
end;

if strcmp(model,'gwr')
    dst2 = Ds2_used;
elseif strcmp(model, 'twr') %�������twrʱ��dtnoncycӦ��������ܵ�ʱ���
    dtnoncyctoSpace = dtTrantoSpace(dtnoncyc,'total');
    dst2 = dtnoncyctoSpace .* dtnoncyctoSpace;
elseif strcmp(model,'ctwr')
    dtcyctoSpace = dtTrantoSpace(dtcyc,'cycle');
    dtnoncyctoSpace = dtTrantoSpace(dtnoncyc,'noncycle');
    dst2 = dtnoncyctoSpace .* dtnoncyctoSpace + dtcyctoSpace .* dtcyctoSpace * omega;
elseif strcmp(model,'gtwr')%�������gtwrʱ��dtnoncycӦ��������ܵ�ʱ���
    dtnoncyctoSpace = dtTrantoSpace(dtnoncyc,'total');
    dst2 = Ds2_used + lamuda * dtnoncyctoSpace.*dtnoncyctoSpace;
elseif strcmp(model,'gctwr')
    dtcyctoSpace = dtTrantoSpace(dtcyc,'cycle');
    dtnoncyctoSpace = dtTrantoSpace(dtnoncyc,'noncycle');
    dt2 = dtnoncyctoSpace .* dtnoncyctoSpace + dtcyctoSpace .* dtcyctoSpace * omega;
    dst2 = Ds2_used + lamuda * dt2;
end;





