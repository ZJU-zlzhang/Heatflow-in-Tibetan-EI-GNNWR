function [] = gctwr_output(model_result, filepath, yname, xname, northname, eastname, timename, cv_index)

global cv_model_iter;

if ~exist(filepath, 'dir')
    mkdir(filepath);
end;

filename = [filepath '/' model_result.meth '_' model_result.meth_abbr '_cv' num2str(cv_index) '.xlsx'];

filename_all = [filepath '/results_cv.xlsx'];

if exist(filename, 'file')
    delete(filename);
end;

train_result = model_result.train_prediction;
val_result = model_result.val_prediction;
test_result = model_result.test_prediction;

% yname = 'CHLA';
% xname = {'constant', 'DO','PH','COD','PO4','TN'};
% northname = 'ProjY';
% eastname = 'ProjX';
xname = ['constant', xname];
xname_coff = cell(1, length(xname));
for iter = 1:length(xname) 
    xname_coff{iter} = [char(xname(iter)) '_weight'];
end;

colheader_data = ['dataset', xname, eastname, northname, timename, yname, [yname '_norm'], [yname '_pre'], [yname '_pre_norm'], 'abs_error', 'rel_error', xname_coff, ['OLS_' yname '_pre'], ['OLS_' yname '_pre_norm']];

dataname_train = repmat({'train'}, length(train_result.pred_y), 1);
dataname_val = repmat({'validation'}, length(val_result.pred_y), 1);
dataname_test = repmat({'test'}, length(test_result.pred_y), 1);

dataname = [dataname_train; dataname_val; dataname_test];

data_train = [train_result.pred_x, train_result.pred_east, train_result.pred_north, train_result.pred_timenoncycle, train_result.y_Real, train_result.pred_y, train_result.yhat_Real, train_result.yhat];
data_train = [data_train, train_result.AE, train_result.APE, train_result.beta];

data_val = [val_result.pred_x, val_result.pred_east, val_result.pred_north, val_result.pred_timenoncycle, val_result.y_Real, val_result.pred_y, val_result.yhat_Real, val_result.yhat];
data_val = [data_val, val_result.AE, val_result.APE, val_result.beta];

data_test = [test_result.pred_x, test_result.pred_east, test_result.pred_north, test_result.pred_timenoncycle, test_result.y_Real, test_result.pred_y, test_result.yhat_Real, test_result.yhat];
data_test = [data_test, test_result.AE, test_result.APE, test_result.beta];

data = [data_train; data_val; data_test];
data = [data model_result.OLSyhat_Real model_result.OLSyhat];

data_cells = num2cell(data);
data_cells = [dataname data_cells];
data_cells = [colheader_data; data_cells];

% Ԥ��������ָ��
colheader_result = {'method' 'dataset', 'RSS', 'MS', 'R2', 'Adjusted_R2', 'r', 'r2', 'RMSE', 'MAE', 'MAPE'};
result_train = [train_result.RSS_Real, train_result.MS, train_result.rsqr, train_result.rbar, train_result.pearson_r, train_result.pearson_r2, train_result.RMSE, train_result.MAE, train_result.MAPE];
result_val = [val_result.RSS_Real, val_result.MS, val_result.rsqr, val_result.rbar, val_result.pearson_r, val_result.pearson_r2, val_result.RMSE, val_result.MAE, val_result.MAPE];
result_test = [test_result.RSS_Real, test_result.MS, test_result.rsqr, test_result.rbar, test_result.pearson_r, test_result.pearson_r2, test_result.RMSE, test_result.MAE, test_result.MAPE];

result_cells = num2cell([result_train; result_val; result_test]);
methods = [{model_result.meth}; {model_result.meth}; {model_result.meth}];
dataname = [{'train'}; {'validation'}; {'test'}];
result_cells = [methods dataname result_cells];
result_cells = [colheader_result; result_cells];

% train�Ľ�����
colheader_train = {'method', 'RSS', 'MS', 'R2', 'Adjusted_R2', 'degree', 'AICc', 'bandwidth', 'lamuda', 'omega', 'F1', 'F1_D1', 'F1_D2', 'F2', 'F2_D1', 'F2_D2'};
result2_train = {model_result.meth, model_result.RSS_Real, model_result.MS, model_result.rsqr, model_result.rbar, model_result.degree, model_result.AICc, model_result.bwidth, model_result.lamuda, model_result.omega, model_result.F1, model_result.F1d1, model_result.F1d2, model_result.F2, model_result.F2d1, model_result.F2d2};

for iter = 1:length(model_result.F3s)
    colheader_train = [colheader_train, {['F3', num2str(iter)], ['F3', num2str(iter), '_D1'], ['F3', num2str(iter), '_D2']}];
    result2_train = [result2_train, {model_result.F3s(iter), model_result.F3d1s(iter), model_result.F3d2s(iter)}];
end;    


result2_train = [colheader_train; result2_train];


% OLS�Ľ�����
ols_train_result = model_result.ols_train_prediction;
ols_val_result = model_result.ols_val_prediction;
ols_test_result = model_result.ols_test_prediction;

colheader_OLS = {'method', 'Train_RSS', 'Train_MS', 'Train_R2', 'Train_Adjusted_R2', 'AICc', 'Train_RMSE', 'Train_MAE', 'Train_MAPE'};
result_OLS = {'OLS', ols_train_result.RSS_Real, ols_train_result.MS, ols_train_result.rsqr, ols_train_result.rbar, model_result.OLSAIC, ols_train_result.RMSE, ols_train_result.MAE, ols_train_result.MAPE};

colheader_OLS = [colheader_OLS {'Val_RSS', 'Val_MS', 'Val_R2', 'Val_r', 'Val_RMSE', 'Val_MAE', 'Val_MAPE'}];
result_OLS = [result_OLS {ols_val_result.RSS_Real, ols_val_result.MS, ols_val_result.rsqr, ols_val_result.pearson_r, ols_val_result.RMSE, ols_val_result.MAE, ols_val_result.MAPE}];

colheader_OLS = [colheader_OLS {'Test_RSS', 'Test_MS', 'Test_R2', 'Test_r', 'Test_RMSE', 'Test_MAE', 'Test_MAPE'}];
result_OLS = [result_OLS {ols_test_result.RSS_Real, ols_test_result.MS, ols_test_result.rsqr, ols_test_result.pearson_r, ols_test_result.RMSE, ols_test_result.MAE, ols_test_result.MAPE}];

result_OLS = [colheader_OLS; result_OLS];


xlswrite(filename, data_cells, 'Sheet1');
xlswrite(filename, result_cells, 'Sheet2');
xlswrite(filename, result2_train, 'Sheet2', 'A6');
xlswrite(filename, result_OLS, 'Sheet2', 'A9');


start_col = 4*cv_model_iter-3;
xlswrite(filename_all, result_cells, 'Sheet1', ['A' num2str(start_col)]);
cv_model_iter = cv_model_iter + 1;



