function [score, RSS, rbar] = gctwrScoreIter(bq,lamuda,omega,y,x,east,north,timecycle,timenoncycle,dtype,CVMethod, excludedzero)

global useQuick;
global logfid;
global kerneltype;
global ymax;
global ymin;
global y_noramlize;
global travel_dis;
global ids_model;

% �� = inverse(X'WX)X'WY
% wt = sqrt(W); xs=wt*x; ys=wt*y
% �� = inverse(xs'xs)xs'ys
% quick�����ǽ�n����ת������άͬʱ���м���

if strcmp(kerneltype, 'fixed')
    [n k] = size(x);
    res = zeros(n,1);   
    s = zeros(n,n);
    % dtype =2 ���� 3ʱ fixed�����㷨��������ܴ��ֵ��
    if ~useQuick || dtype == 2 || dtype == 3
        for iter = 1:n;
            dx = east - east(iter,1);
            dy = north - north(iter,1);
            dtcyc = distTcycleCalculate(timecycle, timecycle(iter,1));
            dtnoncyc = timenoncycle - timenoncycle(iter,1);
            dtnoncyc = travel_dis(ids_model(iter), ids_model).';
            dst2 = distSTCalculate(dx, dy, dtcyc, dtnoncyc, omega, lamuda);
            dst = sqrt(dst2);
            nzip = find(dst <= bq);
            wt = zeros(n,1);
            
            if dtype == 0,     % Gausian weights
                wt = exp(-0.5*dst2/(bq*bq));               
            elseif dtype == 1, % exponential weights
                wt = exp(-1.0*dst/bq);
            elseif dtype == 2, % bi-square weights
                wt(nzip,1) = (1-(dst(nzip,1)/bq).^2).^2;
            elseif dtype == 3, % tri-cube weights
                wt(nzip,1) = (1-(dst(nzip,1)/bq).^3).^3;
            end; % end of if,else
            
            % CV-RSS
            if CVMethod == 0
                if excludedzero
%                     wt(dst2 == 0.0) = 0.0;
                    wt(iter) = 0.0;
                end;
                wt = sqrt(wt);
                % computational trick to speed things up
                % use non-zero wt to pull out y,x observations
                nzip = find(wt > 0.0);
                ys = y(nzip,1).*wt(nzip,1);
                % matmul�����൱�����wt�Ľ������������
                xs = matmul(x(nzip,:),wt(nzip,1));
                xpxi = invpd(xs'*xs);
                bi = xpxi*xs'*ys;
                % compute predicted values
                yhat = x(iter,:)*bi;
                % compute residuals
                res(iter,1) = y(iter,1) - yhat;
                
                % CV-AIC
            else
                wtAICc = sqrt(wt);
                %����в�
                nzip = find(wtAICc > 0.0);
                ys = y(nzip,1).*wtAICc(nzip,1);
                % matmul�����൱�����wt�Ľ������������
                xs = matmul(x(nzip,:),wtAICc(nzip,1));
                xpxi = invpd(xs'*xs);
                bi = xpxi*xs'*ys;
                % compute predicted values
                yhat = x(iter,:)*bi;
                % compute residuals
                res(iter,1) = y(iter,1) - yhat;
                
                %����hat����
                xn = matmul(x,wtAICc);
                s(iter,:) = x(iter,:) * (invpd(xn'*xn) * (matmul(xn,wtAICc))');
            end;
        end; % end of for iter loop
    else
        dx = bsxfun(@minus,east,east');
        dy = bsxfun(@minus,north,north');
        dtcyc = distTcycleCalculate(timecycle, -1);
        dtnoncyc = bsxfun(@minus,timenoncycle,timenoncycle');
        dtnoncyc = travel_dis(ids_model, ids_model);
        dst2 = distSTCalculate(dx, dy, dtcyc, dtnoncyc, omega, lamuda);
        dst = sqrt(dst2);
        col = length(dst2(1,:));
        
        nzip = find(dst <= bq);
        wt = zeros(n,n);
        
        if dtype == 0,     % Gausian weights
            wt = exp(-0.5*dst2/(bq*bq));
        elseif dtype == 1, % exponential weights
            wt = exp(-1.0*dst/(bq));
        elseif dtype == 2, % bi-square weights
            wt(nzip) = (1-(dst(nzip)/bq).^2).^2;
        elseif dtype == 3, % tri-cube weights
            wt(nzip) = (1-(dst(nzip)/bq).^3).^3;
        end; % end of if,else
         
        % CV-RSS
        if CVMethod == 0
            if excludedzero
                % wt(dst2 == 0.0) = 0.0;
                % �Խ�������Ϊ0
                wt(1:1+size(wt,1):end) = 0.0;
            end;
            wt = sqrt(wt);
            
            ys = repmat(y,[1 col]).*wt;
            ys = permute(ys,[1,3,2]);
            
            estXR = repmat(x,[1 1 col]);
            wtR = permute(wt,[1,3,2]);
            wtR = repmat(wtR,[1 length(x(1,:)) 1]);
            xs = estXR.*wtR;
            
            xpxi = mtimesx(xs,'t',xs);
            xpxi = multinv(xpxi);
            bTemp = mtimesx(xpxi,xs,'t');
            b = mtimesx(bTemp,ys);
            xx = permute(x,[3,2,1]);
            yhatTemp = mtimesx(xx,b);
            yhat = permute(yhatTemp,[3,2,1]);
            res = y - yhat;
            % CV-AIC
        else
            wtAICc = sqrt(wt);
            
            ys = repmat(y,[1 col]).*wtAICc;
            ys = permute(ys,[1,3,2]);
            
            estXR = repmat(x,[1 1 col]);
            wtAICR = permute(wtAICc,[1,3,2]);
            wtAICR = repmat(wtAICR,[1 length(x(1,:)) 1]);
            xn = estXR.*wtAICR;
            xpxi = mtimesx(xn,'t',xn);
            xpxi = multinv(xpxi);
            
            %����в�
            bTemp = mtimesx(xpxi,xn,'t');
            b = mtimesx(bTemp,ys);
            xx = permute(x,[3,2,1]);
            yhatTemp = mtimesx(xx,b);
            yhat = permute(yhatTemp,[3,2,1]);
            res = y - yhat;
            
            %����hat����
            xnn = xn.* wtAICR;
            sTemp = mtimesx(xpxi,xnn,'t');
            xx = permute(x,[3,2,1]);
            s = mtimesx(xx,sTemp);
            s = permute(s,[2,3,1]);
        end;
    end;
    RSS = res'*res;
    CV = sqrt(RSS/n);
    
    ym = y - mean(y);
    rsqr1 = RSS;
    rsqr2 = ym'*ym;
    rsqr1 = rsqr1/(n-k);
%     R1 = (eye(n)-s)'*(eye(n)-s);
%     traceR1 = trace(R1);
%     rsqr1 = rsqr1/traceR1;
    rsqr2 = rsqr2/(n-1.0);
    rbar = 1 - (rsqr1/rsqr2); % У�����R2
    
    if CVMethod == 0
        score = CV;
        disp([datestr(now,'HH:MM:SS') ' lamuda:' num2str(lamuda) ', omega:' num2str(omega) ', bdwt:' num2str(bq) ', CV-RSS-Score:' num2str(score) ', RSS:' num2str(RSS) ', adjusted-r2:' num2str(rbar)]);
        fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') ' lamuda:' num2str(lamuda) ', omega:' num2str(omega) ', bdwt:' num2str(bq) ', CV-RSS-Score:' num2str(score) ', RSS:' num2str(RSS) ', adjusted-r2:' num2str(rbar)]);
    elseif CVMethod == 1
        traceS = trace(s);
        %Fortheringham Page 96����׼���������Ȼ���ƽ�������湫ʽû���ˣ�   
%         R1 = (eye(n)-s)'*(eye(n)-s);
%         traceR1 = trace(R1);
        % ����AIC��Ҫ��RSSת����ԭ���ĳ߶�
        if y_noramlize == 1
            RSS_Real = RSS * (ymax-ymin) * (ymax-ymin);
        else
            RSS_Real = RSS;
        end;
        AICc1 = 2 * n * log(sqrt(RSS_Real / n)) + n * log(6.2831853071795862) + n * (n + traceS) / (n - 2.0 - traceS);        
        % ż������ַǳ���ĸ����쳣ֵ������ȡ����ֵ��         
        if AICc1 < -9999
            AICc1 = -AICc1;
        end
        
        score = AICc1;
        disp([datestr(now,'HH:MM:SS') ' lamuda:' num2str(lamuda) ', omega:' num2str(omega) ', bdwt:' num2str(bq) ', CV-AICc-Score:' num2str(score) ', RSS:' num2str(RSS) ', adjusted-r2:' num2str(rbar)]);
        fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') ' lamuda:' num2str(lamuda) ', omega:' num2str(omega) ', bdwt:' num2str(bq) ',CV-AICc-Score:' num2str(score) ', RSS:' num2str(RSS) ', adjusted-r2:' num2str(rbar)]);
    end;
else
    [n k] = size(x);
    % qֵ��Ҫȡ��     
    bq = round(bq);
    res = zeros(n,1);
    s = zeros(n,n);
       
    if ~useQuick
        for iter = 1:n;
            wt = zeros(n,1);
            dx = east - east(iter,1);
            dy = north - north(iter,1);
            dtcyc = distTcycleCalculate(timecycle, timecycle(iter,1));
            dtnoncyc = timenoncycle - timenoncycle(iter,1);
            dtnoncyc = travel_dis(ids_model(iter), ids_model).';
            dst2 = distSTCalculate(dx, dy, dtcyc, dtnoncyc, omega, lamuda);
            dst = sqrt(dst2);
            
            % sort distance to find q nearest neighbors
            dstsort = sort(dst);
            dmax = dstsort(bq,1);
            
            nzip = find(dst <= dmax);
            if dtype == 0,     % Gausian weights
                wt(nzip) = exp(-0.5*dst2(nzip)/(dmax*dmax));
            elseif dtype == 1, % exponential weights
                wt(nzip) = exp(-1.0*dst(nzip)/(dmax));
            elseif dtype == 2, % bi-square weights
                wt(nzip) = (1-(dst(nzip)/dmax).^2).^2;
            elseif dtype == 3, % tri-cube weights
                wt(nzip) = (1-(dst(nzip)/dmax).^3).^3;
            end; % end of if,else
            
            % CV-RSS
            if CVMethod == 0
                if excludedzero
                    % wt(dst2 == 0.0) = 0.0;
                    wt(iter) = 0.0;
                end;
                wt = sqrt(wt);
                % computational trick to speed things up
                % use wt non-zero to pull out y,x observations
                nzip = find(wt(:) > 0);
                ys = y(nzip,1).*wt(nzip);
                xs = matmul(x(nzip,:),wt(nzip));
                xpxi = invpd(xs'*xs);
                bi = xpxi*xs'*ys;
                
                % compute predicted values
                yhat = x(iter,:)*bi;
                % compute residuals
                res(iter) = y(iter) - yhat;
                
            % CV-AIC
            else
                wtAICc = sqrt(wt);
                %����в�
                % computational trick to speed things up
                % use wt non-zero to pull out y,x observations
                nzip = find(wtAICc(:) > 0);
                ys = y(nzip).*wtAICc(nzip);
                xs = matmul(x(nzip,:),wtAICc(nzip));
                xpxi = invpd(xs'*xs);
                bi = xpxi*xs'*ys;
                
                % compute predicted values
                yhat = x(iter,:)*bi;
                % compute residuals
                res(iter) = y(iter) - yhat;
                %����hat����
                xn = matmul(x,wtAICc(:));
                
                if sum(sum(isnan(xn'*xn))) > 0 || sum(sum(isinf(xn'*xn))) > 0
                    s(iter,:) = ones(1, n) * NaN;
                else
                    s(iter,:) = x(iter,:) * (invpd(xn'*xn) * (matmul(xn,wtAICc(:)))');
                end;
            end;
            
        end; % end of for iter loop
    else
        wt = zeros(n,n);
        dx = bsxfun(@minus,east,east');
        dy = bsxfun(@minus,north,north');
        dtcyc = distTcycleCalculate(timecycle, -1);
        dtnoncyc = bsxfun(@minus,timenoncycle,timenoncycle');
        dtnoncyc = travel_dis(ids_model, ids_model);
        dst2 = distSTCalculate(dx, dy, dtcyc, dtnoncyc, omega, lamuda);
        dst = sqrt(dst2);
%         sd = std(dst);
        
        % sort distance to find q nearest neighbors
        dstsort = sort(dst);
        dmax = dstsort(bq,:);
        
            for iter=1:n;
                nzip = find(dst(:,iter) <= dmax(iter));
                if dtype == 0,     % Gausian weights
                    wt(nzip,iter) = exp(-0.5*dst2(nzip,iter)/(dmax(iter)*dmax(iter)));
%                     wt(nzip,iter) = stdn_pdf(dst(nzip,iter)./repmat((sd*dmax(iter))',[1 length(dst2(:,1))])');
                elseif dtype == 1, % exponential weights
                    wt(nzip,iter) = exp(-1.0*dst(nzip,iter)/(dmax(iter)));
                elseif dtype == 2, % bi-square weights
                    wt(nzip,iter) = (1-(dst(nzip,iter)/dmax(iter)).^2).^2;
                elseif dtype == 3, % tri-cube weights
                    wt(nzip,iter) = (1-(dst(nzip,iter)/dmax(iter)).^3).^3;
                end; % end of if,else
            end;
        
        % CV-RSS
        if CVMethod == 0
            if excludedzero
                % wt(dst2 == 0.0) = 0.0;
                % �Խ�������Ϊ0
                wt(1:1+size(wt,1):end) = 0.0;
            end;
            wt = sqrt(wt);            
            wtt = wt;
%             wtt = permute(wtt,[1,3,2]);
            ys = repmat(y,[1 n]).*wtt;
            ys = permute(ys,[1,3,2]);
            
            estXR = repmat(x,[1 1 n]);
            wtR = permute(wtt,[1,3,2]);
            wtR = repmat(wtR,[1 length(x(1,:)) 1]);
            xs = estXR.*wtR;
            
            xpxi = mtimesx(xs,'t',xs);
            xpxi = multinv(xpxi);
            bTemp = mtimesx(xpxi,xs,'t');
            b = mtimesx(bTemp,ys);
            xx = permute(x,[3,2,1]);
            yhatTemp = mtimesx(xx,b);
            yhat = permute(yhatTemp,[3,2,1]);
            res = y - yhat;
            
        % CV-AIC
        else
            wt = sqrt(wt);
            wtt = wt;
%             wtt = permute(wtt,[1,3,2]);
            ys = repmat(y,[1 n]).*wtt;
            ys = permute(ys,[1,3,2]);
            
            estXR = repmat(x,[1 1 n]);
            wtR = permute(wtt,[1,3,2]);
            wtR = repmat(wtR,[1 length(x(1,:)) 1]);
            xn = estXR.*wtR;
            xpxi = mtimesx(xn,'t',xn);
            xpxi = multinv(xpxi);
            
            %����в�
            bTemp = mtimesx(xpxi,xn,'t');
            b = mtimesx(bTemp,ys);
            xx = permute(x,[3,2,1]);
            yhatTemp = mtimesx(xx,b);
            yhat = permute(yhatTemp,[3,2,1]);
            res = y - yhat;
            
            %����hat����
            xnn = xn.* wtR;
            sTemp = mtimesx(xpxi,xnn,'t');
            xx = permute(x,[3,2,1]);
            ss = mtimesx(xx,sTemp);
            ss = permute(ss,[2,3,1]);
            s = ss;
        end;
    end;
    
    % AICc1���㹫ʽ
    % traceS Ϊinvpd(X'WX)X'W �������������Ϊһ����������ɵ�N*N����ļ�
    RSSs = res.*res;
        
    if CVMethod == 0,
        score = sum(RSSs);
        RSS = score;
        score = sqrt(score/n);
        
        ym = y - mean(y);
        rsqr1 = RSS;
        rsqr2 = ym'*ym;
        rsqr1 = rsqr1/(n-k);
%         R1 = (eye(n)-s)'*(eye(n)-s);
%         traceR1 = trace(R1);
%         rsqr1 = rsqr1/traceR1;
        rsqr2 = rsqr2/(n-1.0);
        rbar = 1 - (rsqr1/rsqr2); % У�����R2
        
        disp([datestr(now,'HH:MM:SS') ' lamuda:' num2str(lamuda) ', omega:' num2str(omega) ', q:' num2str(bq) ', CV-RSS-Score:' num2str(score) ', RSS:' num2str(RSS) ', adjusted-r2:' num2str(rbar)]);
        fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') ' lamuda:' num2str(lamuda) ', omega:' num2str(omega) ', q:' num2str(bq) ', CV-RSS-Score:' num2str(score) ', RSS:' num2str(RSS) ', adjusted-r2:' num2str(rbar)]);
    elseif CVMethod == 1,
        hatS = s;
        traceS = trace(hatS);
        
        %Fortheringham Page 96����׼���������Ȼ���ƽ�������湫ʽû���ˣ�
        %             R1 = (eye(n)-hatS)'*(eye(n)-hatS);
        %             traceR1 = trace(R1);
        
        RSS = sum(RSSs);
        % ����AIC��Ҫ��RSSת����ԭ���ĳ߶�
        if y_noramlize == 1
            RSS_Real = RSS * (ymax-ymin) * (ymax-ymin);
        else
            RSS_Real = RSS;
        end;
        AICc1 = 2 * n * log(sqrt(RSS_Real / n)) + n * log(6.2831853071795862) + n * (n + traceS) / (n - 2.0 - traceS);
        % ż������ַǳ���ĸ����쳣ֵ������ȡ����ֵ��
        if AICc1 < -9999
            AICc1 = -AICc1;
        end
        score = AICc1;
      
        ym = y - mean(y);
        rsqr1 = RSS;
        rsqr2 = ym'*ym;
        rsqr1 = rsqr1/(n-k);
%         R1 = (eye(n)-hatS)'*(eye(n)-hatS);
%         traceR1 = trace(R1);
%         rsqr1 = rsqr1/traceR1;
        rsqr2 = rsqr2/(n-1.0);
        rbar = 1 - (rsqr1/rsqr2); % У�����R2

        disp([datestr(now,'HH:MM:SS') ' lamuda:' num2str(lamuda) ', omega:' num2str(omega) ', q:' num2str(bq) ', CV-AICc-Score:' num2str(score) ', RSS:' num2str(RSS) ', adjusted-r2:' num2str(rbar)]);
        fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') ' lamuda:' num2str(lamuda) ', omega:' num2str(omega) ', q:' num2str(bq) ',CV-AICc-Score:' num2str(score) ', RSS:' num2str(RSS) ', adjusted-r2:' num2str(rbar)]);
    end;
end;


