function rbarInverse = gctwrScorefLamuda(lamuda,omegamin,omegamax,bmin,bmax,qmin,qmax,y,x,east,north,timecycle,timenoncycle,dtype,method)
% PURPOSE: evaluates cross-validation score for optimal gtwr bandwidth
%          with gauusian or exponential weighting
% ------------------------------------------------------
% USAGE: score = gtwrScorefLamuda(lamuda,bdwt,y,x,east,north,time,dtype)
% where: y = dependent variable
%        x = matrix of explanatory variables
%     east = longitude (x-direction) coordinates
%    north = lattitude (y-direction) coordinates
%     time = time
%     bdwt = a bandwidth to use in computing the score
%     flag = 0 for Gaussian weights
%          = 1 for BFG exponential
% ------------------------------------------------------
% RETURNS: score = a cross-validation criterion
% ------------------------------------------------------
% SEE ALSO: scoreq that determines optimal q-value for
%           tricube weighting
% ------------------------------------------------------

global logfid;
global omegaIntervalSize;
global bdwtIntervalSize;
global qIntervalSize;
global model;
global bestFunVars;
global kerneltype;
global minbandwidth;

disp([datestr(now,'HH:MM:SS') '--------------begin lamuda:' num2str(lamuda)]);
fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') '--------------begin lamuda:' num2str(lamuda)]);

funVars.y = y;
funVars.x = x;
funVars.timecycle = timecycle;
funVars.timenoncycle = timenoncycle;
funVars.east = east;
funVars.north = north;
funVars.dtype = dtype;
funVars.bmin = bmin;
funVars.bmax = bmax;
funVars.qmin = qmin;
funVars.qmax = qmax;
funVars.lamuda = lamuda;
funVars.omegamin = omegamin;
funVars.omegamax = omegamax;
funVars.method = method;

if strcmp(model,'gctwr')
    %lamuda=0����ΪGWRģ�ͣ�������omega
    if lamuda == 0
        omega = 0;
        funVars.omega = omega;
        if strcmp(kerneltype,'fixed')
            if minbandwidth == 1
                minBand = calMinBandwidth(lamuda, omega);
                funVars.bmin = minBand;
                bmin = minBand;
            end;            
            maxBand = calBandwidth(lamuda, omega, -1);
            funVars.bmax = maxBand;
            rmsearch('gctwrScorefBandwidth','fminbnd',bmin,bmin,maxBand,funVars,'initialsample',bdwtIntervalSize,'plot','off');
        else
            rmsearch('gctwrScorefBandwidth','fminbnd',qmin,qmin,qmax,funVars,'initialsample',qIntervalSize,'plot','off');
        end;
        
        bdwt = bestFunVars.bestBQ;
        bestFunVars.bestOmega = omega;
    else
        rmsearch('gctwrScorefOmega','fminbnd',omegamin,omegamin,omegamax,funVars,'initialsample',omegaIntervalSize,'plot','off');
        omega = bestFunVars.bestOmega;
        bdwt = bestFunVars.bestBQ;        
    end;
    
    [~, ~, rbar] = gctwrScoreIter(bdwt,lamuda,omega,y,x,east,north,timecycle,timenoncycle,dtype, method, 0);
    
elseif strcmp(model,'gtwr')
    omega = 0;
    funVars.omega = omega;
    if strcmp(kerneltype,'fixed')
        if minbandwidth == 1
            minBand = calMinBandwidth(lamuda, omega);
            funVars.bmin = minBand;
            bmin = minBand;
        end;
        maxBand = calBandwidth(lamuda, omega, -1);        
        funVars.bmax = maxBand;
        rmsearch('gctwrScorefBandwidth','fminbnd',bmin,bmin,maxBand,funVars,'initialsample',bdwtIntervalSize,'plot','off');        
    else
        rmsearch('gctwrScorefBandwidth','fminbnd',qmin,qmin,qmax,funVars,'initialsample',qIntervalSize,'plot','off');
    end;
    
    bdwt = bestFunVars.bestBQ;   
    [~, ~, rbar] = gctwrScoreIter(bdwt,lamuda,omega,y,x,east,north,timecycle,timenoncycle,dtype, method, 0);
    bestFunVars.bestOmega = omega; 
end;
                
rbarInverse = 1-rbar; % У�����1-R2��С

fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') '--------------end lamuda:' num2str(lamuda)]); 
disp([datestr(now,'HH:MM:SS') '--------------end lamuda:' num2str(lamuda)]); 
