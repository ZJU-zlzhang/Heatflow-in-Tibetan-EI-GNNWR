function score = gctwrScorefBandwidth(bq,lamuda,omega,y,x,east,north,timecycle,timenoncycle,dtype,method)

[score, ~, ~] = gctwrScoreIter(bq,lamuda,omega,y,x,east,north,timecycle,timenoncycle,dtype, method,1);



