function rbarInverse = gctwrScorefOmega(omega,lamuda,bmin,bmax,qmin,qmax,y,x,east,north,timecycle,timenoncycle,dtype,method)
% PURPOSE: evaluates cross-validation score for optimal gtwr bandwidth
%          with gauusian or exponential weighting
% ------------------------------------------------------
% USAGE: score = gtwrScorefLamuda(lamuda,bdwt,y,x,east,north,time,dtype)
% where: y = dependent variable
%        x = matrix of explanatory variables
%     east = longitude (x-direction) coordinates
%    north = lattitude (y-direction) coordinates
%     time = time
%     bdwt = a bandwidth to use in computing the score
%     flag = 0 for Gaussian weights
%          = 1 for BFG exponential
% ------------------------------------------------------
% RETURNS: score = a cross-validation criterion
% ------------------------------------------------------
% SEE ALSO: scoreq that determines optimal q-value for
%           tricube weighting
% ------------------------------------------------------

% written by: James P. LeSage 2/98
% University of Toledo
% Department of Economics
% Toledo, OH 43606
% jpl@jpl.econ.utoledo.edu
global logfid;
global bdwtIntervalSize;
global qIntervalSize;
global bestFunVars;
global kerneltype;
global minbandwidth;

disp([datestr(now,'HH:MM:SS') '--------------begin omega:' num2str(omega)]);
fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') '--------------begin omega:' num2str(omega)]);

funVars.y = y;
funVars.x = x;
funVars.timecycle = timecycle;
funVars.timenoncycle = timenoncycle;
funVars.east = east;
funVars.north = north;
funVars.dtype = dtype;
funVars.bmin = bmin;
funVars.bmax = bmax;
funVars.qmin = qmin;
funVars.qmax = qmax;
funVars.lamuda = lamuda;
funVars.omega = omega;
funVars.method = method;

if strcmp(kerneltype,'fixed')
    if minbandwidth == 1
        minBand = calMinBandwidth(lamuda, omega);
        funVars.bmin = minBand;
        bmin = minBand;
    end;
    %����ʱ�վ�������ֵ������bmax�����ֵ����Ϊ����
    funVars.bmax = calBandwidth(lamuda, omega, -1);
    rmsearch('gctwrScorefBandwidth','fminbnd',bmin,bmin,funVars.bmax,funVars,'initialsample',bdwtIntervalSize,'plot','off');   
else
    rmsearch('gctwrScorefBandwidth','fminbnd',qmin,qmin,qmax,funVars,'initialsample',qIntervalSize,'plot','off');
end;
bdwt = bestFunVars.bestBQ;
[~, ~, rbar] = gctwrScoreIter(bdwt,lamuda,omega,y,x,east,north,timecycle,timenoncycle,dtype, method, 0);

rbarInverse = 1-rbar; % У�����1-R2��С

fprintf(logfid,'%s\n', [datestr(now,'HH:MM:SS') '--------------end omega:' num2str(omega)]); 
disp([datestr(now,'HH:MM:SS') '--------------end omega:' num2str(omega)]); 
