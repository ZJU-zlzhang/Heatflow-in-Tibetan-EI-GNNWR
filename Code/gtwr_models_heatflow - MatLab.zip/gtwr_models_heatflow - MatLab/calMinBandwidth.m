function minBandwidth = calMinBandwidth(lamuda, omega)
global maxDs;
global minDs;
global maxDtcycle;
global maxDtnoncycle;
global maxDt;
global model;
global distNormalize;
global minpoints;
global minpoint_rate;

global Ds;
global Dtcycle;
global Dtnoncycle;
global Dttotal;

if distNormalize == 1
    maxDs_used = 1;
    Ds_used = (Ds - minDs) / (maxDs - minDs);
else
    maxDs_used = maxDs;
    Ds_used = Ds;
end;

if strcmp(model,'gwr')
    maxDst = maxDs_used;    
    dst = Ds_used;
    
elseif strcmp(model, 'twr') %�������twrʱ��dtnoncycӦ��������ܵ�ʱ���
    maxDtnoncyctoSpace = dtTrantoSpace(maxDt,'total');
    maxDst = maxDtnoncyctoSpace;
    
    dtnoncyctoSpace = dtTrantoSpace(Dttotal,'total');
    dst = dtnoncyctoSpace;
    
elseif strcmp(model,'ctwr')
    maxDtcyctoSpace = dtTrantoSpace(maxDtcycle,'cycle');
    maxDtnoncyctoSpace = dtTrantoSpace(maxDtnoncycle,'noncycle');
    maxDst = sqrt(maxDtnoncyctoSpace * maxDtnoncyctoSpace + maxDtcyctoSpace * maxDtcyctoSpace * omega);
    
    dtcyctoSpace = dtTrantoSpace(Dtcycle,'cycle');
    dtnoncyctoSpace = dtTrantoSpace(Dtnoncycle,'noncycle');
    dst = sqrt(dtnoncyctoSpace .* dtnoncyctoSpace + dtcyctoSpace .* dtcyctoSpace * omega);
    
    
elseif strcmp(model,'gtwr')%�������gtwrʱ��dtnoncycӦ��������ܵ�ʱ���
    maxDtnoncyctoSpace = dtTrantoSpace(maxDt,'total');
    maxDst = sqrt(maxDs_used * maxDs_used + lamuda * maxDtnoncyctoSpace * maxDtnoncyctoSpace);
    
    dtnoncyctoSpace = dtTrantoSpace(Dttotal,'total');
    dst = sqrt(Ds_used .* Ds_used + lamuda * dtnoncyctoSpace .* dtnoncyctoSpace);
    
elseif strcmp(model,'gctwr')
    maxDtcyctoSpace = dtTrantoSpace(maxDtcycle,'cycle');
    maxDtnoncyctoSpace = dtTrantoSpace(maxDtnoncycle,'noncycle');
    maxDt2 = maxDtnoncyctoSpace * maxDtnoncyctoSpace + maxDtcyctoSpace * maxDtcyctoSpace * omega;
    maxDst = sqrt(maxDs_used * maxDs_used + lamuda * maxDt2);
    
    dtcyctoSpace = dtTrantoSpace(Dtcycle,'cycle');
    dtnoncyctoSpace = dtTrantoSpace(Dtnoncycle,'noncycle');
    dt2 = dtnoncyctoSpace .* dtnoncyctoSpace + dtcyctoSpace .* dtcyctoSpace * omega;
    dst = sqrt(Ds_used .* Ds_used + lamuda * dt2);
end;

% ��dst�е�0ֵ�滻����֮���ҵ���Сֵ��������Ϊ��С��bandwidth����֤ÿ���㶼�����ҵ���
[n, ~] = size(dst);
dst(dst == 0) = 9999999;
% dst(1:n+1:end) = 9999999;
sortdst = sort(dst);
sortdst = sort(sortdst(minpoints,:));
minBandwidth = sortdst(int64(n * minpoint_rate));

if distNormalize == 1
    minBandwidth = minBandwidth / maxDst;
end;
