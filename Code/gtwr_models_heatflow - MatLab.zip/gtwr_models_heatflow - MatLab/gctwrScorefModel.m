function [lamuda, omega, bdwt] = gctwrScorefModel(lamudamin,lamudamax,omegamin,omegamax,bmin,bmax,qmin,qmax,y,x,east,north,timecycle,timenoncycle,dtype,method)
% PURPOSE: evaluates cross-validation score for optimal gctwr bandwidth

global omegaIntervalSize;
global bdwtIntervalSize;
global qIntervalSize;
global lamudaIntervalSize;
global model;
global bestFunVars;
global kerneltype;
global minbandwidth;

funVars.y = y;
funVars.x = x;
funVars.timecycle = timecycle;
funVars.timenoncycle = timenoncycle;
funVars.east = east;
funVars.north = north;
funVars.dtype = dtype;
funVars.bmin = bmin;
funVars.bmax = bmax;
funVars.qmin = qmin;
funVars.qmax = qmax;
funVars.omegamin = omegamin;
funVars.omegamax = omegamax;
funVars.lamudamin = lamudamin;
funVars.lamudamax = lamudamax;
funVars.method = method;

if strcmp(model,'gwr')
    lamuda = 0;
    omega = 0;
    funVars.lamuda = lamuda;
    funVars.omega = omega;
    if strcmp(kerneltype,'fixed')
        if minbandwidth == 1
            minBand = calMinBandwidth(lamuda, omega);
            funVars.bmin = minBand;
            bmin = minBand;
        end;
        maxBand = calBandwidth(lamuda, omega, -1);
        funVars.bmax = maxBand;
        rmsearch('gctwrScorefBandwidth','fminbnd',bmin,bmin,maxBand,funVars,'initialsample',bdwtIntervalSize,'plot','off');    
    else
        rmsearch('gctwrScorefBandwidth','fminbnd',qmin,qmin,qmax,funVars,'initialsample',qIntervalSize,'plot','off');
    end;
    bdwt = bestFunVars.bestBQ;
    
elseif strcmp(model, 'twr')
    lamuda = 1;
    omega = 0;
    funVars.lamuda = lamuda;
    funVars.omega = omega;
    if strcmp(kerneltype,'fixed')
        if minbandwidth == 1
            minBand = calMinBandwidth(lamuda, omega);
            funVars.bmin = minBand;
            bmin = minBand;
        end;
        maxBand = calBandwidth(lamuda, omega, -1);
        funVars.bmax = maxBand;
        rmsearch('gctwrScorefBandwidth','fminbnd',bmin,bmin,maxBand,funVars,'initialsample',bdwtIntervalSize,'plot','off');
    else
        rmsearch('gctwrScorefBandwidth','fminbnd',qmin,qmin,qmax,funVars,'initialsample',qIntervalSize,'plot','off');
    end;
    bdwt = bestFunVars.bestBQ;
    
elseif strcmp(model,'ctwr')
    lamuda = 1;
    funVars.lamuda = lamuda;
    rmsearch('gctwrScorefOmega','fminbnd',omegamin,omegamin,omegamax,funVars,'initialsample',omegaIntervalSize,'plot','off');    
    omega = bestFunVars.bestOmega;
    bdwt = bestFunVars.bestBQ;
elseif strcmp(model,'gtwr')
    omega = 0;
    funVars.omega = omega;
    rmsearch('gctwrScorefLamuda','fminbnd',lamudamin,lamudamin,lamudamax,funVars,'initialsample',lamudaIntervalSize,'plot','off');    
    lamuda = bestFunVars.bestLamuda;
    bdwt = bestFunVars.bestBQ;
elseif strcmp(model,'gctwr')
    rmsearch('gctwrScorefLamuda','fminbnd',lamudamin,lamudamin,lamudamax,funVars,'initialsample',lamudaIntervalSize,'plot','off');    
    lamuda = bestFunVars.bestLamuda;
    omega = bestFunVars.bestOmega;
    bdwt = bestFunVars.bestBQ;
end;

bestFunVars.bestLamuda = lamuda;
bestFunVars.bestOmega = omega;
bestFunVars.bestBQ = bdwt;


